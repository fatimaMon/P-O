package m19.app.users;


import m19.LibraryManager;
import pt.tecnico.po.ui.Command;
import pt.tecnico.po.ui.DialogException;
import pt.tecnico.po.ui.Input;
import m19.app.exceptions.UserRegistrationFailedException;
import m19.exceptions.BadEntrySpecificationException;





/**
 * 4.2.1. Register new user.
 */
public class DoRegisterUser extends Command<LibraryManager>  {

Input <String> _name;
Input <String> _email;
private static int _id = 1;

  /**
   * @param receiver
   */
  public DoRegisterUser(LibraryManager receiver) {
       super(Label.REGISTER_USER, receiver);
      _name  =  _form.addStringInput(Message.requestUserName());
      _email =  _form.addStringInput(Message.requestUserEMail());
  }


  public int getId( )
  {
    return _id;
  }
  public void incrementId( )
  {
     _id++;
  }
  
  /** @see pt.tecnico.po.ui.Command#execute() */
  @Override
  public final void execute() throws DialogException{

    _form.parse();

      try
      {
        _receiver.userRegister(_name.value(), _email.value(),_id);
        _display.popup(Message.userRegistrationSuccessful(_id));
        incrementId();

      }catch(BadEntrySpecificationException e)
{       
        throw new UserRegistrationFailedException(_name.value(), _email.value());
        
}
    
  }

}
