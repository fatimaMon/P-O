package m19;
import java.io.Serializable;


public class User implements Serializable{
  
   private String _userName;
   private String _userEmail;
   private int  _userId = 0;
   private static final long serialVersionUID = 201608231530L;

   
   public User (String name, String email, int  userId)
   {
        _userName = name;
        _userEmail = email;
        _userId = userId;


   }
       
   public int getUserId()
   {
       return _userId;
   }
   public String getUserName()
   {
       return _userName;

   }

   public String getUserEmail()
   {
       return _userEmail;
   }
    

   public String toString()
   {
       return getUserId() + " - " + getUserName() + " - " + getUserEmail();
   }
      }
    
