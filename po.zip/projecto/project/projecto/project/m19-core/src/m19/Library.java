package m19;

import m19.exceptions.BadEntrySpecificationException;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;


/**
 * Class that represents the library as a whole.
 */
public class Library implements Serializable {

  /** Serial number for serialization. */
  private static final long serialVersionUID = 201901101348L;
  private int _id = 1;

  private Map <Integer, User> _users = new TreeMap<Integer, User> ();

  

  public void AddUser(User newUser) 
{
     
    _users.put(newUser.getUserId(), newUser);

 }


  public void registerUser(String name, String email, int id) 
  {
      User user = new User(name, email, id);
      if(!_users.containsKey(user.getUserId()))
        AddUser(user);

  }

  public User findUser(int id) throws BadEntrySpecificationException
  {
    if(_users.containsKey(id))
     return _users.get(id);
    else
        throw new BadEntrySpecificationException("No such find user");
  }

  public Collection<User> getUsers() 
  {
    return Collections.unmodifiableCollection(_users.values());
  }



  /**
   * Read the text input file at the beginning of the program and populates the
   * instances of the various possible types (books, DVDs, users).
   * 
   * @param filename
   *          name of the file to load
   * @throws BadEntrySpecificationException
   * @throws IOException
   */
  void importFile(String filename) throws BadEntrySpecificationException, IOException {
    // FIXME implement method
  }

}
