package m19;

import java.io.Serializable;

public class FirstRule extends RulesStrategy implements Serializable{

    private static final long serialVersionUID = 201608231530L;

    private int _ruleIndex = 1;

    @Override
    public int getRuleIndex() {
        return _ruleIndex;
    }

    @Override
    public boolean verifyRule(User user, Work work) {
        for(Integer requestedWorkId: user.getRequestedWorks())
        {
            if (requestedWorkId.equals(work.getWorkId()))
                return false; 
        }
        return true;   
    }
}

