package m19;

public class NormalUser extends UserBehavior {

    private Types _userBehavior = Types.NORMAL;
    private static final long serialVersionUID = 201608231530L;

    @Override
    public void changeToNormal(User user) {
        user.changeBehavior(new NormalUser());
    }

    @Override
    public void changeToIrresponsible(User user) {
        if (user.getFaultsRecord() == 3) {
            user.changeBehavior(new IrresponsibleUser());
        }
    }

    @Override
    public void changeToResponsible(User user) {
        if (user.getReturnsOnTime() == 5)
            user.changeBehavior(new ResponsibleUser());
    }

    @Override
    public String getUserType() {
        return _userBehavior.getUserType().toString();
    }

}