package m19;

public class DVD extends Work {

    private static final long serialVersionUID = 201608231530L;

    private String _maker;
    private String _IGAC;

    public DVD(String workType, String title, String maker, int price, Category category, String IGAC, int totalCopies, int idWork) {
        super(workType, title, price, category, totalCopies, idWork, maker);
        _IGAC = IGAC;
        _maker = maker;
    }

    public String getMaker() {
        return _maker;
    }

    public String getIGAC() {
        return _IGAC;
    }

    @Override
    public String toString() {
        return super.toString() + " - " + _maker + " - " + _IGAC;
    }

}