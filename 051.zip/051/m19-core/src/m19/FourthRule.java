package m19;

import java.io.Serializable;

public class FourthRule extends RulesStrategy implements Serializable {

    private static final long serialVersionUID = 201608231530L;

    private int _ruleIndex = 4;

    @Override
    public int getRuleIndex() {
        return _ruleIndex;
    }

    @Override
    public boolean verifyRule(User user, Work work) {
        String userBehavior = user.getUserBehavior().getUserType();
        if (userBehavior.equals("NORMAL")) {
            return user.getRequestedWorks().size() >= 0 && user.getRequestedWorks().size() < 3;
        } else if (userBehavior.equals("CUMPRIDOR")) {
            return user.getRequestedWorks().size() >= 0 && user.getRequestedWorks().size() <5;
        } else if (userBehavior.equals("FALTOSO")) {
            return user.getRequestedWorks().size() >= 0 && user.getRequestedWorks().size() <1;
        } else
            return false;
    }

}