
package m19.exceptions;

/**
 * Exception for  npt borrowed work.
 */

public class NotBorrowedWorkException extends Exception {

  /** Serial number for serialization. */
  private static final long serialVersionUID = 201901101348L;

  private String _entryMessage;

  /**
   * @param entryMessage
   */
  public NotBorrowedWorkException(String entryMessage) {
    _entryMessage = entryMessage;
  }

  /**
   * @param entryMessage
   * @param cause
   */
  public NotBorrowedWorkException(String entryMessage, Exception cause) {
    super(cause);
    _entryMessage = entryMessage;
  }

  /**
   * @return the bad entry message.
   */
  public String getEntryMessage() {
    return _entryMessage;
  }

}
