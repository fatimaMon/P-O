package m19.exceptions;

/**
 * Exception for unknown import file entries.
 */
public class ThirdRuleFailedException extends Exception {

  /** Serial number for serialization. */
  private static final long serialVersionUID = 201901101348L;

  private String _entryMessage;

  /**
   * @param entryMessage
   */
  public ThirdRuleFailedException(String entryMessage) {
    _entryMessage = entryMessage;
  }

  /**
   * @param entryMessage
   * @param cause
   */
  public ThirdRuleFailedException(String entryMessage, Exception cause) {
    super(cause);
    _entryMessage = entryMessage;
  }

  /**
   * @return the bad entry message.
   */
  public String getEntryMessage() {
    return _entryMessage;
  }

}
