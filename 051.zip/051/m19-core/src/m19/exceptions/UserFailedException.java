package m19.exceptions;

/**
 * Exception for unknown import file entries.
 */
public class UserFailedException extends Exception {

  /** Serial number for serialization. */
  private static final long serialVersionUID = 201901101348L;

  private String _entryMessage;

  /**
   * @param entryMessage
   */
  public UserFailedException(String entryMessage) {
    _entryMessage = entryMessage;
  }

  /**
   * @param entryMessage
   * @param cause
   */
  public UserFailedException(String entryMessage, Exception cause) {
    super(cause);
    _entryMessage = entryMessage;
  }

  /**
   * @return the bad entry message.
   */
  public String getEntryMessage() {
    return _entryMessage;
  }

}
