package m19;

public class ResponsibleUser extends UserBehavior {

    private Types _userBehavior = Types.RESPONSIBLE;
    private static final long serialVersionUID = 201608231530L;

    @Override
    public void changeToNormal(User user) {
        if(user.getFaultsRecord() == 1)
        user.changeBehavior(new NormalUser());
    }

    @Override
    public void changeToIrresponsible(User user) {
        if (user.getFaultsRecord() == 3)
            user.changeBehavior(new IrresponsibleUser());
    }

    @Override
    public void changeToResponsible(User user) {
        user.changeBehavior(new ResponsibleUser());
    }

    @Override
    public String getUserType() {
        return _userBehavior.getUserType().toString();
    }

}