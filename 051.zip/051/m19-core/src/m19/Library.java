package m19;

import m19.exceptions.BadEntrySpecificationException;
import m19.exceptions.ImportFileException;
import m19.exceptions.NotBorrowedWorkException;
import m19.exceptions.RequestRuleFailedException;
import m19.exceptions.ThirdRuleFailedException;
import m19.exceptions.UserFailedException;
import m19.exceptions.UserHasFineToPayException;
import m19.exceptions.UserIsNotSuspendedException;
import m19.exceptions.WorkFailedException;
import java.io.*;
import java.util.*;
import java.lang.String;

/**
 * Class that represents the library as a whole.
 */
public class Library implements Serializable {

  /**
   * Serial number for serialization.
   */
  private static final long serialVersionUID = 201901101348L;

  private int _userId;
  private int _workId;
  private int _date;
  private int _ruleIndex;
  private Map<Integer, User> _users;
  private Map<Integer, Work> _works;


  public Library() {
    _users = new TreeMap<Integer, User>();
    _works = new TreeMap<Integer, Work>();
    _userId = 0;
    _workId = 0;
    _date = 0;
  }

  /**
   * @param name
   * @param email
   * @return User - that has been registered with a new userId.
   */
  public User registerUser(String name, String email) throws BadEntrySpecificationException {

    if (name.length() > 0 && email.length() > 0) {
      User user = new User(name, email, _userId++);
      _users.put(user.getUserId(), user);
      return user;
    }
    throw new BadEntrySpecificationException("User registration failed.");
  }

  /**
   * @param userId
   * @return User - existing User found with given id.
   * @throws BadEntrySpecificationException.
   */
  public User findUser(int userId) throws UserFailedException {
    if (_users.containsKey(userId))
      return _users.get(userId);
    else
      throw new UserFailedException("User does not exist.");
  }

  /**
   * @return Collection of all existing Users in the Library, organized by the
   *         names alphabetically.
   */
  public Collection<User> getUsers() {
    ArrayList<User> mapTolist = new ArrayList<User>(_users.values());
    Collections.sort(mapTolist, User.NAME_COMPARISON);
    return Collections.unmodifiableCollection(mapTolist);
  }

  /**
   * @param workType  - String with the name of the type of Work being added to
   *                  the Library.
   * @param title     - the title of the book to be added.
   * @param author    - the author of the book to be added.
   * @param price     - the price of the book to be added.
   * @param category  - the category to which the book belongs to.
   * @param ISBN      - the ISBN of the book to be added.
   * @param numCopies - The total number of copies of the book.
   */
  public void registerBook(String workType, String title, String author, int price, Category category, String ISBN,
      int numCopies) {
    Work book = new Book(workType, title, author, price, category, ISBN, numCopies, _workId);
    _works.put(_workId++, book);
  }

  /**
   * @param workType  - String with the name of the type of Work being added to
   *                  the Library.
   * @param title     - the title of the dvd to be added.
   * @param maker     - the maker of the dvd to be added.
   * @param price     - the price of the dvd to be added.
   * @param category  - the category to which the dvd belongs to.
   * @param IGAC      - the IGAC of the dvd to be added.
   * @param numCopies - The total number of copies of the dvd.
   */
  public void registerDVD(String workType, String title, String maker, int price, Category category, String IGAC, int numCopies) {
    Work dvd = new DVD(workType, title, maker, price, category, IGAC, numCopies, _workId);
    _works.put(_workId++, dvd);
  }

  /**
   * @param workId - workId of the work to be found in the Library.
   * @return Work - registered work in the Library.
   * @throws BadEntrySpecificationException
   */
  public Work findWork(int workId) throws WorkFailedException {
    if (_works.containsKey(workId))
      return _works.get(workId);
    else
      throw new WorkFailedException("Work does not exist.");
  }

  /**
   * @param searchTerm
   * @return String containing all the works that contain the term that was searched for.
   */
  public String performSearch(String searchTerm) {
    String findTerm = "";
    for (Work work : _works.values())
    {
      String title = work.getTitle().toLowerCase();
      String author = work.getAuthorMaker().toLowerCase();
      if (title.contains(searchTerm.toLowerCase()) || author.contains(searchTerm.toLowerCase()))
      {
        findTerm += work.toString() + "\n";
      }
    }
    return findTerm;
  }

  /**
   * @param userId
   * @return String containing all the notifications that will be sent to the user.
   * @throws UserFailedException
   */
  public String showUserNotifications(int userId) throws UserFailedException {
    User user = findUser(userId);
    List<String> notifications = user.getNotications();
    String allNotifications = "";
    if (notifications.size() != 0)
    {
      for (String notification : notifications)
      {
        allNotifications += notification + "\n";
      }
    }
    user.removeNotifications();
    return allNotifications;
  }

  /**
   * Adds the user that is interested in a work to the interested user list.
   *
   * @param userPreference
   * @param userId
   * @param workId
   * @throws UserFailedException
   * @throws WorkFailedException
   */
  public void sendNotification(String userPreference, int userId, int workId)
      throws UserFailedException, WorkFailedException {
    if ("s".equals(userPreference))
    {
      User user = findUser(userId);
      Work work = findWork(workId);
      work.addInterestedUser(user);
    }
  }

  /**
   * @return Collection - with all the works registered in the Library, sorted by
   *         their Id's.
   */
  public Collection<Work> getWorks() {
    return Collections.unmodifiableCollection(_works.values());
  }

  /**
   * @param inputCategory
   * @return Category - found Category in the Library.
   */
  public Category findCategory(String inputCategory) {
    switch (inputCategory)
    {
      case "REFERENCE":
        return Category.REFERENCE;
      case "SCITECH":
        return Category.SCITECH;
      case "FICTION":
        return Category.FICTION;
    }
    return null;
  }

  /**
   * @return latest rule failed.
   */
  public int getRulefailedIndex() {
    return _ruleIndex;
  }

  /**
   * @param userId
   * @param workId
   * @return day in which the user must return the work
   */
  public int getDevolutionDay(int userId, int workId) {
    Work work = _works.get(workId);
    return _users.get(userId).getReturnDate(work);
  }

  /**
   *  Updates all users throughout the passing of days of the Library.
   */
  public void updateAllUsers() {
    for (User user : _users.values())
    {
      for (Request request : user.getRequests())
      {
        if (_date - request.getReturnDate() > 0)
        {
          request.setLateReturnDate(_date - request.getReturnDate());
          user.setState(false);          
        }
       
      }
    }
  }

  /**
   * @param user
   * @return true if the user has a work in debt.
   */
  public boolean verifyUserWorkInDebt(User user) {
    for (Request request : user.getRequests())
    {
      if (request.getLateReturnDate() != 0)
        return true;
    }
    return false;
  }

  /**
   * User requests a new work and all the verifications are made to check the status of the user,
   * updating it where necessary.
   *
   * @param userId
   * @param workId
   * @throws ThirdRuleFailedException
   * @throws RequestRuleFailedException
   * @throws UserFailedException
   * @throws WorkFailedException
   */
  public void requestWork(int userId, int workId) throws ThirdRuleFailedException, RequestRuleFailedException, UserFailedException, WorkFailedException {
    VerifyRules verificator = new VerifyRules();
    User user = findUser(userId);
    Work work = findWork(workId);

    if (verificator.verifyRule(user, work))
    {
      if (verificator.getThirdRuleFlag())
      {
        throw new ThirdRuleFailedException("Third rule failed: user notification");
      }
      else
      {
        RequestObservable requestProcessor = new RequestObservable(user, work);
        requestProcessor.updateCurrentDate(_date);
        requestProcessor.processRequest();
      }
    }
    else
    {
      if (verificator.getThirdRuleFlag())
      {
        throw new ThirdRuleFailedException("Third rule failed: user notification");
      }

      _ruleIndex = verificator.getRuleIndex();
      throw new RequestRuleFailedException("Rule failed");
    }
  }

  /**
   * User returns a specific work.
   *
   * @param userId
   * @param workId
   * @throws UserFailedException
   * @throws WorkFailedException
   * @throws NotBorrowedWorkException
   * @throws UserHasFineToPayException
   */
  public void returnWork(int userId, int workId) throws UserFailedException, WorkFailedException, NotBorrowedWorkException, UserHasFineToPayException {
    Work work = findWork(workId);
    User user = findUser(userId);

    if (user.getRequestedWorks().contains(work.getWorkId()))
    {
      RequestObservable requestProcessor = new RequestObservable(user, work);
      requestProcessor.updateCurrentDate(_date);
      requestProcessor.processReturnWork();

      if (user.getAmountInDebt() > 0)
      {
        throw new UserHasFineToPayException(user.getAmountInDebt());
      }

    } else
        throw new NotBorrowedWorkException("User has not requested the work.");
  }

  /**
   * User pays the amount of a specific work.
   *
   * @param userId
   * @param paymentChoice
   * @throws UserFailedException
   * @throws UserIsNotSuspendedException
   */
  public void payFine(int userId, String paymentChoice) throws UserFailedException, UserIsNotSuspendedException {
    if (paymentChoice.length() > 0 && "s".equals(paymentChoice))
    {
      payTotalFine(userId);
    }
  }

  /**
   * User pays the total amount owed.
   *
   * @param userId
   * @throws UserFailedException
   * @throws UserIsNotSuspendedException
   */
  public void payTotalFine(int userId) throws UserFailedException, UserIsNotSuspendedException {
    User user = findUser(userId);
    if (!user.getState())
    {
      user.payAmountInDebt(verifyUserWorkInDebt(user));
    }
    else
    {
      throw new UserIsNotSuspendedException("User does not have fine to pay.");
    }
  }

  /**
   * @param days
   */
  public void advanceDate(int days) {
    if (days > 0)
    {
      _date = _date + days;
      updateAllUsers();
    }
  }

  /**
   * @return current date of the Library.
   */
  public int showDate() {
    return _date;
  }

  /**
   * Read the text input file at the beginning of the program and populates the
   * instances of the various possible types (books, DVDs, users).
   *
   * @param filename name of the file to load
   * @throws BadEntrySpecificationException
   * @throws IOException
   */
  void importFile(String filename) throws BadEntrySpecificationException, IOException, ImportFileException {
    try
    {
      BufferedReader input = new BufferedReader(new FileReader(filename));
      String string;

      while ((string = input.readLine()) != null)
      {
        String line = new String(string.getBytes(), "UTF-8");
        String[] data = line.split(":");
        String entryType = data[0];
        if (entryType.equals("BOOK"))
        {
          entryType = "Livro";
          Category category = findCategory(data[4]);
          registerBook(entryType, data[1], data[2], Integer.parseInt(data[3]), category, data[5],
              Integer.parseInt(data[6]));
        }
        else if (entryType.equals("DVD"))
        {
          Category category = findCategory(data[4]);
          registerDVD(entryType, data[1], data[2], Integer.parseInt(data[3]), category, data[5],
              Integer.parseInt(data[6]));
        }
        else if (entryType.equals("USER"))
        {
          registerUser(data[1], data[2]);
        }
        else
        {
          input.close();
          throw new BadEntrySpecificationException(entryType);
        }
      }
      input.close();
    } catch (FileNotFoundException | NullPointerException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }


}