package m19;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;

public abstract class Work implements  Observer, Serializable {

    private static final long serialVersionUID = 201608231530L;

    private int _idWork;
    private int _totalCopies;
    private String _title;
    private int _price;
    private int _availableCopies;
    private Category _category;
    private String _workType;
    private String _authorMaker;
    private ArrayList<User> _interestedUsers = new ArrayList<User>();
    public static final Comparator<Work> WORKID_COMPARISON = new IntegerComparator();

    public Work(String workType, String title, int price, Category category, int totalCopies, int idWork,
        String authorMaker) {
        _title = title;
        _price = price;
        _category = category;
        _availableCopies = totalCopies;
        _totalCopies = totalCopies;
        _idWork = idWork;
        _workType = workType;
        _authorMaker = authorMaker;
    }

    public int getWorkId() {
        return _idWork;
    }

    public int getTotalCopies() {
        return _totalCopies;
    }

    public String getTitle() {
        return _title;
    }

    public String getAuthorMaker() {
        return _authorMaker;
    }

    public int getPrice() {
        return _price;
    }

    public String getWorkType() {
        return _workType;
    }

    public int getAvailableCopies() {
        return _availableCopies;
    }

    public ArrayList <User> getInterestedUsers() {
        return _interestedUsers;
    }

    public Category getCategory() {
        return _category;
    }

    @Override
    public void update(int availableCopies, UserBehavior behavior, int amountInDebt) {
        _availableCopies = availableCopies;
    }

    public void addInterestedUser(User user){
        _interestedUsers.add(user);
    }

    private static class IntegerComparator implements Comparator<Work>, Serializable {
        private static final long serialVersionUID = 201608231530L;
        @Override
        public int compare(Work firstWork, Work secondWork) {
            return firstWork.getWorkId() - secondWork.getWorkId();
        }
    }

    @Override
    public String toString() {
        return _idWork + " - " + _availableCopies + " de  " + _totalCopies + " - " + _workType + " - " + _title + " - "
                + _price + " - " + _category.CategoryOutput();
    }

}