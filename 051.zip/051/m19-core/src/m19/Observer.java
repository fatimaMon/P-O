package m19;

public interface Observer {

    public void update(int availableCopies, UserBehavior behavior, int amountInDebt);

}
