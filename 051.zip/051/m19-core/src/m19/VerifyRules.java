package m19;

import java.util.*;

import m19.UserBehavior.Types;

import java.io.Serializable;

public class VerifyRules extends RulesStrategy implements Serializable {

    private static final long serialVersionUID = 201608231530L;

    private List<RulesStrategy> _rules = new ArrayList<RulesStrategy>();
    private boolean _thirdRuleFlag = false;
    private int _failedRuleIndex = 0;
    private int _workReturnDate = 0;

    public VerifyRules() {
        _rules.add(new FirstRule());
        _rules.add(new SecondRule());
        _rules.add(new ThirdRule());
        _rules.add(new FourthRule());
        _rules.add(new FifthRule());
        _rules.add(new SixthRule());
    }

    public boolean getThirdRuleFlag() {
        return _thirdRuleFlag;
    }

    @Override
    public int getRuleIndex() {
        return _failedRuleIndex;
    }

    @Override
    public boolean verifyRule(User user, Work work) {
        for (RulesStrategy rule : _rules) {
            if (!rule.verifyRule(user, work)) {
                if (rule.getRuleIndex() == 3) {
                    _thirdRuleFlag = true;
                    continue;
                }
                _failedRuleIndex = rule.getRuleIndex();
                return false;
            }
        }
        return true;
    }

    public int verifyWorkReturnDate(User user, Work work) {
        String userBehavior = user.getUserBehavior().getUserType();
        int availableCopies = work.getTotalCopies();

        if (userBehavior.equals(Types.NORMAL.getUserType())) {
            if (availableCopies == 1)
                _workReturnDate = 3;
            if (availableCopies > 1 && availableCopies <= 5)
                _workReturnDate = 8;
            if (availableCopies > 5)
                _workReturnDate = 15;
        } else if (userBehavior.equals(Types.RESPONSIBLE.getUserType())) {
            if (availableCopies == 1)
                _workReturnDate = 8;
            if (availableCopies > 1 && availableCopies <= 5)
                _workReturnDate = 15;
            if (availableCopies > 5)
                _workReturnDate = 30;
        } else
            _workReturnDate = 2;
        
        return _workReturnDate;
    }

}