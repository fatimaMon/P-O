package m19;

import java.io.Serializable;

public class SecondRule extends RulesStrategy implements Serializable {
    private static final long serialVersionUID = 201608231530L;

    private int _ruleIndex = 2;

    @Override
    public int getRuleIndex() {
        return _ruleIndex;
    }

    @Override
    public  boolean verifyRule(User user, Work work) {
        return user.getState() != false;
    }
}