package m19;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

import m19.UserBehavior.Types;

public class RequestObservable implements Observable, Serializable {

    private static final long serialVersionUID = 201608231530L;
    List<Observer> _observers = new ArrayList<Observer>();

    private int _availableCopies;
    private int _amountInDebt = 0;
    private UserBehavior _userBehavior;
    private int _currentDate;
    private User _user;
    private Work _work;

    public RequestObservable(User user, Work work) {
        _work = work;
        _user = user;
    }

    public void updateCurrentDate(int currentDate) {
        _currentDate = currentDate;
    }

    public UserBehavior verifyBehavior(UserBehavior behavior) {
        String userBehavior = behavior.getUserType();

        if (userBehavior.equals(Types.NORMAL.getUserType())) {
            behavior.changeToIrresponsible(_user);
            behavior.changeToResponsible(_user);
        } else if (userBehavior.equals(Types.RESPONSIBLE.getUserType())) {
            behavior.changeToNormal(_user);
        } else 
            behavior.changeToNormal(_user);
         
        return _user.getUserBehavior();
    }

    public void processRequest() {
        VerifyRules verificator = new VerifyRules();
        int returnDay = verificator.verifyWorkReturnDate(_user, _work);
        UserBehavior userBehavior = _user.getUserBehavior();

        if (_user.getState()) {
            Request request = new Request(returnDay + _currentDate);
            _userBehavior = verifyBehavior(userBehavior);
            _user.addRequestedWork(_work, request);
            _availableCopies = _work.getAvailableCopies() - 1;
            _work.update(_availableCopies, _userBehavior, _amountInDebt);
            _user.update(_availableCopies, _userBehavior, _amountInDebt);
          
        }
    }

    public void processReturnWork() {

        if(_user.getReturnDate(_work) >= _currentDate) {
            if (_user.getState()) 
                _user.increaseReturnsOnTime();
            else 
                _user.increaseReturnsOnTime();
        }
        else if(_user.getReturnDate(_work) < _currentDate)  {
            _amountInDebt = _user.getWorkLateReturn(_work) * 5;
            _user.increaseFaultsRecord();
        }   

        _availableCopies = _work.getAvailableCopies() + 1;
        _user.returnRequestedWork(_work);
        _userBehavior = verifyBehavior(_user.getUserBehavior());
        _work.update(_availableCopies, _userBehavior, _amountInDebt);
        _user.update(_availableCopies, _userBehavior, _amountInDebt);
        notifyObservers(_work);
        removeObservers();
    }


    @Override
    public void registerObserver(Observer observer) {
        if (!_observers.contains(observer)) {
            _observers.add(observer);
        }
    }
    @Override
    public void removeObservers() {
         _work.getInterestedUsers().clear();
    }
    @Override
    public void notifyObservers(Work work) {
        ArrayList<User> interestedUsers = work.getInterestedUsers();
        if (interestedUsers.size() > 0) {
            for (User interestedUser : interestedUsers)
                interestedUser.setNotification("ENTREGA: " + work.toString());
        
        }
    }

}