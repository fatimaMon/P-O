package m19;

import java.io.Serializable;



public class  Request implements Serializable {
    
    private static final long serialVersionUID = 201608231530L;
    
    private int _returnDate;
    private int _lateReturnDate;
    
    public Request(int returnDate){
        _returnDate = returnDate;
        _lateReturnDate = 0;
    }

    public int getReturnDate() {
        return _returnDate;
    }

    public int getLateReturnDate() {
        return _lateReturnDate;
    }

    public void setReturnDate(int returnDate) {
        _returnDate = returnDate;
    }

    public void setLateReturnDate(int lateReturnDate){
        _lateReturnDate = lateReturnDate;
    }

}    
