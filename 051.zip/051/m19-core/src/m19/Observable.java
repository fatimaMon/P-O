package m19; 

public interface Observable  {
 
    public void registerObserver(Observer o);
    public void removeObservers();
    public void notifyObservers(Work work);
    
}