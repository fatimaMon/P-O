package m19;

import java.io.Serializable;

public class Book extends Work implements Serializable {

    private static final long serialVersionUID = 201608231530L;

    private String _author;
    private String _ISBN;

    public Book(String workType, String title, String author, int price, Category category, String ISBN,
            int totalCopies, int idWork) {
        super(workType, title, price, category, totalCopies, idWork, author);
        _author = author;
        _ISBN = ISBN;
    }

    public String getAuthor() {
        return _author;
    }

    public String getISBN() {
        return _ISBN;
    }

    @Override
    public String toString() {
        return super.toString() + " - " + _author + " - " + _ISBN;
    }

}