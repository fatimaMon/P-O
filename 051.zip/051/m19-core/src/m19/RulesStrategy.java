package m19;

import java.io.Serializable;

public abstract class RulesStrategy implements Serializable {
    
    private static final long serialVersionUID = 201608231530L;

    public abstract boolean verifyRule(User user, Work work);
    public abstract int getRuleIndex();

}