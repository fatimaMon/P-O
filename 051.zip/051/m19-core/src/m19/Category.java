package m19;

import java.io.Serializable;

public enum Category implements Serializable {

    FICTION("Ficção"), SCITECH("Técnica e Científica"), REFERENCE("Referência");

    private static final long serialVersionUID = 201608231530L;

    private final String _categoryType;

    Category(String category) {
        _categoryType = category;
    }

    public String CategoryOutput() {
        return _categoryType;
    }

}
