package m19;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeMap;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

public class User implements Observer, Serializable {

    private static final long serialVersionUID = 201608231530L;
    
    private String _userName;
    private String _userEmail;
    private int _userId;
    private UserBehavior _behavior = new NormalUser();
    private boolean _active = true;
    private int _faultsRecord = 0; 
    private int _returnsOnTime = 0;
    private int _amountInDebt = 0; 

    private TreeMap<Integer, Request> _requestedWorks = new TreeMap<Integer, Request>();
    private List<String> _notifications = new CopyOnWriteArrayList<String>();

    public static final Comparator<User> NAME_COMPARISON = new NameComparator();

    public User(String name, String email, int userId) {
        _userName = name;
        _userEmail = email;
        _userId = userId;
    }

    public void changeBehavior(UserBehavior behavior) {
        _behavior = behavior;
    }

    public int getUserId() {
        return _userId;
    }

    public void addRequestedWork(Work work, Request requestData) {
        _requestedWorks.put(work.getWorkId(), requestData);
    }

    public List<Integer> getRequestedWorks() {
        List<Integer> worksId = new ArrayList<Integer>();
        Set<Integer> requestedsKey = _requestedWorks.keySet();
        for (Integer workId : requestedsKey) 
        {
            worksId.add(workId);
        }
        return worksId;
    }

    public Collection<Request> getRequests() {
        List<Request> requests = new ArrayList<Request>();
        for (Request request : _requestedWorks.values()) 
        {
            requests.add(request);
        }
        return Collections.unmodifiableCollection(requests);
    }

    public int getWorkLateReturn(Work work) {
        return _requestedWorks.get(work.getWorkId()).getLateReturnDate();
    }

    public void returnRequestedWork(Work work) {
        _requestedWorks.remove(work.getWorkId());
    }

    public String getUserName() {
        return _userName;
    }

    public String getUserEmail() {
        return _userEmail;
    }

    public void setState(boolean state) {
        _active = state;
    }

    public boolean getState() {
        return _active;
    }

    public UserBehavior getUserBehavior() {
        return _behavior;
    }

    public int getFaultsRecord() {
        return _faultsRecord;
    }

    public void increaseFaultsRecord() {
        _faultsRecord++;
        if (_returnsOnTime != 0)
            _returnsOnTime = 0;
    }

    public void increaseReturnsOnTime() {
        _returnsOnTime++;
        if (_faultsRecord != 0)
            _faultsRecord = 0;
    }

    public int getReturnDate(Work work) {
        return _requestedWorks.get(work.getWorkId()).getReturnDate();
    }

    public int getReturnsOnTime() {
        return _returnsOnTime;
    }

    public int getAmountInDebt() {
        return _amountInDebt;
    }

    public void payAmountInDebt(boolean amountInDebt) {
        _amountInDebt = 0;
        if (amountInDebt == false)
            _active = true;
    }

    public List<String> getNotications() {
        return _notifications;
    }

    public void setNotification(String notification) {
        _notifications.add(notification);
    }

    public void removeNotifications() {
        for (String notification : _notifications)
            _notifications.remove(notification);
    }

    public String stateToString() {
        if (_active == true)
            return "ACTIVO";
        return "SUSPENSO - EUR " + getAmountInDebt();
    }

    @Override
    public void update(int availableCopies, UserBehavior behavior, int amountInDebt) {
        _amountInDebt += amountInDebt;
        changeBehavior(behavior);
    }

    @Override
    public String toString() {
        return getUserId() + " - " + getUserName() + " - " + getUserEmail() + " - " + _behavior.getUserType() + " - "
                + stateToString();
    }

    private static class NameComparator implements Comparator<User> {

        @Override
        public int compare(User firstUser, User secondUser) {
            return firstUser.getUserName().compareToIgnoreCase(secondUser.getUserName());
        }
    }

}