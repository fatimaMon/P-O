package m19;

import java.io.Serializable;

public class ThirdRule extends RulesStrategy implements Serializable{
    private static final long serialVersionUID = 201608231530L;
    private int _ruleIndex = 3;

    @Override
    public int getRuleIndex() {
        return _ruleIndex;
    }

    @Override
    public boolean verifyRule(User user, Work work) {

       return work.getAvailableCopies() > 0; 
    }
}