package m19;

import java.io.Serializable;

public abstract class UserBehavior implements Serializable {
    private static final long serialVersionUID = 201608231530L;

    public enum Types {

        NORMAL("NORMAL"), RESPONSIBLE("CUMPRIDOR"), IRRESPONSIBLE("FALTOSO");

        String _name;

        Types(String name) {
            this._name = name;
        }

        public String getUserType() {
            return _name;
        }
    }

    public abstract void changeToNormal(User user);

    public abstract void changeToIrresponsible(User user);

    public abstract void changeToResponsible(User user);

    public abstract String getUserType();

}