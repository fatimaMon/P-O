package m19;

import m19.exceptions.BadEntrySpecificationException;
import m19.exceptions.FailedToOpenFileException;
import m19.exceptions.ImportFileException;
import m19.exceptions.MissingFileAssociationException;
import m19.exceptions.RequestRuleFailedException;
import m19.exceptions.UserFailedException;
import m19.exceptions.ThirdRuleFailedException;
import m19.exceptions.WorkFailedException;
import m19.exceptions.NotBorrowedWorkException;
import m19.exceptions.UserHasFineToPayException; 
import m19.exceptions.UserIsNotSuspendedException;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.*;
import java.util.*;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;

/**
 * The facade class.
 */
public class LibraryManager {

    private Library _library = new Library();
    private String _filename = "";

    public User userRegister(String name, String email) throws BadEntrySpecificationException, NullPointerException {
        return _library.registerUser(name, email);
    }

    public User showUser(int userId) throws UserFailedException {
        return _library.findUser(userId);
    }

    public Collection<User> showUsers() {
        return _library.getUsers();
    }

    public boolean existFile() {
        return _filename.length() > 0;
    }

    public Work showWork(int workId) throws WorkFailedException {
        return _library.findWork(workId);
    }

    public Collection<Work> showWorks() {
        return _library.getWorks();
    }

    public String performSearch(String searchTerm) {
        return _library.performSearch(searchTerm);
    }

    public void requestWork(int userId, int workdId) throws ThirdRuleFailedException, RequestRuleFailedException, UserFailedException, WorkFailedException {
             _library.requestWork(userId, workdId);
    }

    public int getRulefailedIndex() {
        return _library.getRulefailedIndex();
    }

    public void sendNotification(String userPreference, int userId, int workId) throws UserFailedException, WorkFailedException {
        _library.sendNotification(userPreference, userId, workId);
    }

    public int showDate() {
        return _library.showDate();
    }

    public void advanceDate(int days) {
        _library.advanceDate(days);
    }

    public int getDevolutionDay(int userId, int workId) {
        return _library.getDevolutionDay(userId, workId);
    }

    public void returnWork(int userId, int workId) throws UserFailedException, WorkFailedException, NotBorrowedWorkException, UserHasFineToPayException {
        _library.returnWork(userId, workId);
    }

    public void payFine(int userId, String paymentChoice) throws UserFailedException, UserIsNotSuspendedException {
        _library.payFine(userId, paymentChoice);
    }

    public void payTotalFine(int userId) throws UserFailedException, UserIsNotSuspendedException {
        _library.payTotalFine(userId);
    }

    public String showUserNotifications(int userId) throws UserFailedException {
        return _library.showUserNotifications(userId);
    }

    /**
     * @throws MissingFileAssociationException
     * @throws IOException
     * @throws FileNotFoundException
     */
    public void save() throws IOException, MissingFileAssociationException {
        if (!existFile())
            throw new MissingFileAssociationException();
        else 
        {
            ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(_filename)));
            out.writeObject(_library);
            out.close();
        }
    }

    /**
     * @param filename
     * @throws MissingFileAssociationException
     * @throws IOException
     */
    public void saveAs(String filename) throws IOException, MissingFileAssociationException {
        _filename = filename;
        save();
    }

    /**
     * @param filename
     * @throws FailedToOpenFileException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public void load(String filename) throws FailedToOpenFileException, IOException, ClassNotFoundException {
        try 
        {
            ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(filename)));
            Library previousLibrary = (Library) ois.readObject();
            if (previousLibrary != null) 
            {
                _library = previousLibrary;
                _filename = filename;
                ois.close();
            }
            else 
            {
                ois.close();
                throw new FailedToOpenFileException(filename);
            }
        } catch (NullPointerException | FileNotFoundException e) {
            throw new FailedToOpenFileException(filename);
        }
    }

    /**
     * @param datafile
     * @throws ImportFileException
     */
    public void importFile(String datafile) throws ImportFileException {
        try 
        {
            _library.importFile(datafile);
        } catch (IOException | BadEntrySpecificationException e) {
            throw new ImportFileException(e);
        }
    }
}
