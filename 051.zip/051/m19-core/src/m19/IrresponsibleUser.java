package m19;

public class IrresponsibleUser extends UserBehavior {

    private static final long serialVersionUID = 201608231530L;

    private Types _userBehavior = Types.IRRESPONSIBLE;

    @Override
    public void changeToNormal(User user) {
        if (user.getReturnsOnTime() == 3)
            user.changeBehavior(new NormalUser());
    }

    @Override
    public void changeToIrresponsible(User user) {
        user.changeBehavior(new IrresponsibleUser());
    }

    @Override
    public void changeToResponsible(User user) {
        user.changeBehavior(new IrresponsibleUser());
    }

    @Override
    public String getUserType() {
        return _userBehavior.getUserType().toString();
    }

}