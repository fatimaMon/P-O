package m19.app.requests;

import m19.LibraryManager;
import pt.tecnico.po.ui.Command;
import pt.tecnico.po.ui.DialogException;
import m19.exceptions.NotBorrowedWorkException;
import m19.exceptions.UserFailedException;
import m19.exceptions.WorkFailedException;
import m19.app.exceptions.WorkNotBorrowedByUserException;
import m19.app.exceptions.NoSuchWorkException;
import m19.app.exceptions.NoSuchUserException;
import m19.exceptions.UserHasFineToPayException;
import m19.exceptions.UserIsNotSuspendedException;
import pt.tecnico.po.ui.Command;
import pt.tecnico.po.ui.DialogException;
import pt.tecnico.po.ui.Input;

/**
 * 4.4.2. Return a work.
 */
public class DoReturnWork extends Command<LibraryManager> {

  Input<Integer> _userId;
  Input<Integer> _workId;
  Input<String> _payFineChoice;

  /**
   * @param receiver
   */
  public DoReturnWork(LibraryManager receiver) {
    super(Label.RETURN_WORK, receiver);
  }

  /** @see pt.tecnico.po.ui.Command#execute() */
  @Override
  public final void execute() throws DialogException {

    _userId = _form.addIntegerInput(Message.requestUserId());
    _workId = _form.addIntegerInput(Message.requestWorkId());
    _form.parse();
    _form.clear();
    try 
    {
      _receiver.returnWork(_userId.value(), _workId.value());
    } catch (UserFailedException e) {
        throw new NoSuchUserException(_userId.value());
    } catch (WorkFailedException e) {
        throw new NoSuchWorkException(_workId.value());
    } catch (NotBorrowedWorkException e) {
        throw new WorkNotBorrowedByUserException(_workId.value(), _userId.value());
    } catch (UserHasFineToPayException e) {
        _display.popup(Message.showFine(_userId.value(), e.getFine()));
        _payFineChoice = _form.addStringInput(Message.requestFinePaymentChoice());
        _form.parse();
        _form.clear();
        try 
        {
          _receiver.payFine(_userId.value(), _payFineChoice.value());
        } catch (UserIsNotSuspendedException | UserFailedException a) {
          a.printStackTrace();
        }
    }
  }

}
