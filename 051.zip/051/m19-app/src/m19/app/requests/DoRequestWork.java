package m19.app.requests;

import m19.LibraryManager;
import m19.exceptions.BadEntrySpecificationException;
import pt.tecnico.po.ui.Command;
import pt.tecnico.po.ui.DialogException;
import pt.tecnico.po.ui.Input;
import m19.app.exceptions.NoSuchWorkException;
import m19.app.exceptions.NoSuchUserException;
import m19.app.exceptions.RuleFailedException;
import m19.exceptions.RequestRuleFailedException;
import m19.exceptions.UserFailedException;
import m19.exceptions.WorkFailedException;
import m19.exceptions.ThirdRuleFailedException;

/**
 * 4.4.1. Request work.
 */
public class DoRequestWork extends Command<LibraryManager> {

  Input <Integer> _userId; 
  Input <Integer> _workId; 
  Input <String> _userPreference;

  /**
   * @param receiver
   */
  public DoRequestWork(LibraryManager receiver) {
    super(Label.REQUEST_WORK, receiver);
  }

  /** @see pt.tecnico.po.ui.Command#execute() */
  @Override
  public final void execute() throws DialogException {

    _form.clear();
    _userId = _form.addIntegerInput(Message.requestUserId()); 
    _workId = _form.addIntegerInput(Message.requestWorkId());
    _form.parse();  
    try 
    {
      _receiver.requestWork(_userId.value(), _workId.value()); 
      _display.popup(Message.workReturnDay(_workId.value(),_receiver.getDevolutionDay(_userId.value(), _workId.value())));
    } catch (UserFailedException e){
        throw new NoSuchUserException(_userId.value());
    } catch(WorkFailedException e) {
      throw new NoSuchWorkException(_workId.value());
    } catch(ThirdRuleFailedException e) {
      _form.clear();
      _userPreference = _form.addStringInput(m19.app.requests.Message.requestReturnNotificationPreference()); 
      _form.parse();
      try 
      {
      _form.clear();     
      _receiver.sendNotification(_userPreference.value(), _userId.value(), _workId.value());
      } catch( UserFailedException | WorkFailedException a) {
          a.printStackTrace();
      }
    } catch(RequestRuleFailedException a) {
      throw new RuleFailedException(_userId.value(),_workId.value(),_receiver.getRulefailedIndex());
    }
  }

}


