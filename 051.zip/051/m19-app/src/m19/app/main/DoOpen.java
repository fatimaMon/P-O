package m19.app.main;

import m19.LibraryManager;
import pt.tecnico.po.ui.Command;
import pt.tecnico.po.ui.DialogException;
import m19.app.exceptions.FileOpenFailedException;
import m19.exceptions.FailedToOpenFileException;
import java.io.IOException;
import pt.tecnico.po.ui.Input;


/**
 * 4.1.1. Open existing document.
 */
public class DoOpen extends Command<LibraryManager> {

  Input <String> _file;

  /**
   * @param receiver
   */
  public DoOpen(LibraryManager receiver)
  {
    super(Label.OPEN, receiver);
    _file = _form.addStringInput(Message.openFile());
  }

  /** @see pt.tecnico.po.ui.Command#execute() */
  @Override
  public final void execute() throws DialogException
  {
    try
    {
      _form.parse();
      _receiver.load(_file.value());
    } 
    catch (FailedToOpenFileException fnfe) {
      throw new FileOpenFailedException(fnfe.getName());
    } catch (ClassNotFoundException | IOException e) {
      e.printStackTrace();
    }
  }

}
